--TEST--
bug #61820 using ob_gzhandler will complain about headers already sent when no compression
--SKIPIF--
<?php
if (!extension_loaded('brotli')) {
    die('skip');
}
?>
--FILE--
<?php
ob_start('ob_brotli_handler');

echo "Hi there.\n";
ob_flush();
flush();

echo "This is confusing...\n";
ob_flush();
flush();
?>
DONE
--EXPECT--
Hi there.
This is confusing...
DONE
